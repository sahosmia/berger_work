<?php $__env->startSection('about'); ?>
active
<?php $__env->stopSection(); ?>


<?php $__env->startSection('content'); ?>
<h1>About</h1>
<h1>About</h1>
<h1>About</h1>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\berger_work\resources\views/about.blade.php ENDPATH**/ ?>