<?php echo e($slot); ?>

<?php /**PATH C:\Users\sahos\OneDrive\Desktop\berger\vendor\laravel\framework\src\Illuminate\Mail/resources/views/text/footer.blade.php ENDPATH**/ ?>