<?php $__env->startSection('slider'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-12">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e(session()->get('success')); ?></p>
    </div>

    <?php endif; ?>
    <div class="card">
        <div class="card-header bg-teal text-light">
            <a href="<?php echo e(route('admin.slider_add')); ?>" class="btn btn-primary" data-toggle="tooltip" data-placement="top" title="Tooltip on top">Add New</a>
        </div>
        <div class="card-body">
            <table class="table table-striped">
                <thead>
                    <tr>
                        <th>No</th>
                        <th>Image</th>
                        <th>Title</th>
                        <th>Heading</th>
                        <th>Button</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>

                 <?php $__empty_1 = true; $__currentLoopData = $data; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                 <tr>
                    <th><?php echo e($data->firstItem()+$key); ?></th>
                    <th style="width: 400px"><img class="w-75" src="<?php echo e(asset('uploads/slider')); ?>/<?php echo e($item->img); ?>" alt="<?php echo e($item->img); ?>"></th>
                    <th><?php echo e($item->title); ?></th>
                    <th><?php echo e($item->heading); ?></th>
                    <th><?php echo e($item->btn_text); ?></th>

                    <th><div class="btn-group" role="group" aria-label="Basic example">
                        <a href="<?php echo e(url('admin/slider_delete')); ?>/<?php echo e($item->id); ?>" class="btn btn-danger pd-x-25 "><i class="fa fa-trash"></i></a>
                        <a href="<?php echo e(url('admin/slider_edit')); ?>/<?php echo e($item->id); ?>" class="btn btn-warning pd-x-25"><i class="fa fa-edit"></i></a>
                        <a href="<?php echo e(url('admin/slider_action')); ?>/<?php echo e($item->id); ?>" class="btn btn-teal pd-x-25"><i class="fa fa-eye<?php echo e($item->action == 2 ? "-slash" : ""); ?>"></i></a>
                      </div>
                    </th>
                </tr>
                 <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                 <tr>
                    <th colspan="50">No Data To Show</th>
                </tr>
                 <?php endif; ?>
                </tbody>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\berger_work\resources\views/admin/slider.blade.php ENDPATH**/ ?>