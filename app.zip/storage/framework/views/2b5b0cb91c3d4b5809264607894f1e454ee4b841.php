<?php $__env->startComponent('mail::message'); ?>
    <?php echo $data; ?>

<?php echo $__env->renderComponent(); ?>
<?php /**PATH C:\Users\sahos\OneDrive\Desktop\berger\resources\views/Admin/Contacttemplate.blade.php ENDPATH**/ ?>