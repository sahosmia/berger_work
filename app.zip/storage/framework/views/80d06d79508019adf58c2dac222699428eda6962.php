<?php $__env->startSection('home'); ?>
active
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
 <!-- banner pert start  -->
 <div class="banner">
    <div id="carouselExampleIndicators" class="carousel slide" data-bs-ride="carousel">
        <div class="carousel-indicators">
            <?php
                $i=0;
            ?>
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <button type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide-to="<?php echo e($i); ?>" class="<?php echo e($loop->first ? 'active' : ''); ?>" aria-current="true" aria-label="Slide <?php echo e($i+1); ?>"></button>
                <?php
                    $i++
                ?>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </div>
        <div class="carousel-inner">
            <?php $__currentLoopData = $sliders; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>

          <div class="carousel-item <?php echo e($loop->first ? 'active' : ''); ?>">
            <img src="<?php echo e(asset('uploads/slider')); ?>/<?php echo e($item->img); ?>" class="d-block w-100" alt="<?php echo e($item->img); ?>">
            <div class="carousel-caption">
                <p class="animated fadeInRight"><?php echo e($item->title); ?></p>
                <h1 class="animated fadeInLeft"><?php echo e($item->heading); ?></h1>
                <a class="btn animated fadeInUp" href="<?php echo e($item->btn_url); ?>"><?php echo e($item->btn_text); ?></a>
            </div>
          </div>
          <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        </div>
        <button class="carousel-control-prev" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="prev">
          <span class="carousel-control-prev-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Previous</span>
        </button>
        <button class="carousel-control-next" type="button" data-bs-target="#carouselExampleIndicators" data-bs-slide="next">
          <span class="carousel-control-next-icon" aria-hidden="true"></span>
          <span class="visually-hidden">Next</span>
        </button>
      </div>
</div>



<!-- portfolio start  -->
<section class="portfolio">
   <div class="heading_content">
    <div class="container-fluid">
        <div class="row">
           <div class="col-lg-10 m-auto">
            <h1 class="heading">Paint your imagination</h1>
            <p>Choose from a wide variety of products made to fit all your needs</p>
           </div>
        </div>
    </div>
   </div>
   <div class="portfolio_item">
    <div class="container_fluid">
        <div class="row">
          <div class="col-lg-6 portfolio_single">
              <img class="w-100 img-fluid portfolio_img" src="<?php echo e(asset('uploads/portfolio')); ?>/<?php echo e($portfolio->find(1)->img); ?>" alt="portfolio_1">
              <a href="#" class="portfolio_caption"><?php echo e($portfolio->find(1)->title); ?></a>
          </div>
          <div class="col-lg-3 portfolio_single">
              <img class="w-100 img-fluid portfolio_img" src="<?php echo e(asset('uploads/portfolio')); ?>/<?php echo e($portfolio->find(2)->img); ?>" alt="portfolio_1">
              <a href="#" class="portfolio_caption"><?php echo e($portfolio->find(2)->title); ?></a>
          </div>
          <div class="col-lg-3 portfolio_single">
              <img class="w-100 img-fluid portfolio_img" src="<?php echo e(asset('uploads/portfolio')); ?>/<?php echo e($portfolio->find(3)->img); ?>" alt="portfolio_1">
              <a href="#" class="portfolio_caption"><?php echo e($portfolio->find(3)->title); ?></a>
          </div>
          <div class="col-lg-5 portfolio_single">
              <img class="w-100 img-fluid portfolio_img" src="<?php echo e(asset('uploads/portfolio')); ?>/<?php echo e($portfolio->find(4)->img); ?>" alt="portfolio_1">
              <a href="#" class="portfolio_caption"><?php echo e($portfolio->find(4)->title); ?></a>
          </div>
          <div class="col-lg-7 portfolio_single">
              <img class="w-100 img-fluid portfolio_img" src="<?php echo e(asset('uploads/portfolio')); ?>/<?php echo e($portfolio->find(5)->img); ?>" alt="portfolio_1">
              <a href="#" class="portfolio_caption"><?php echo e($portfolio->find(5)->title); ?></a>
          </div>


        </div>
     </div>
   </div>

</section>
<!-- portfolio end  -->
 <!-- Fact Start -->
 <div class="fact">
    <div class="container-fluid">
        <div class="row counters">
            <div class="col-md-6 fact-left wow slideInLeft">
                <div class="row">
                    <div class="col-6">
                        <div class="fact-icon">
                            <i class="flaticon-worker"></i>
                        </div>
                        <div class="fact-text">
                            <h2 data-toggle="counter-up"><?php echo e($counter->find(1)->counter_num); ?></h2>
                            <p><?php echo e($counter->find(1)->counter_title); ?></p>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="fact-icon">
                            <i class="flaticon-building"></i>
                        </div>
                        <div class="fact-text">
                            <h2 data-toggle="counter-up"><?php echo e($counter->find(2)->counter_num); ?></h2>
                            <p><?php echo e($counter->find(2)->counter_title); ?></p>
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-md-6 fact-right wow slideInRight" style="background-color: #A00000">
                <div class="row">
                    <div class="col-6">
                        <div class="fact-icon">
                            <i class="flaticon-address"></i>
                        </div>
                        <div class="fact-text">
                            <h2 data-toggle="counter-up"><?php echo e($counter->find(3)->counter_num); ?></h2>
                            <p><?php echo e($counter->find(3)->counter_title); ?></p>
                        </div>
                    </div>
                    <div class="col-6">
                        <div class="fact-icon">
                            <i class="flaticon-crane"></i>
                        </div>
                        <div class="fact-text">
                            <h2 data-toggle="counter-up"><?php echo e($counter->find(4)->counter_num); ?></h2>
                            <p><?php echo e($counter->find(4)->counter_title); ?></p>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
</div>
<!-- Fact End -->



<!-- contact Requisition -->

<section class="contact" style="background-image: url('<?php echo e(asset('frontend/images/background-sparkle.jpg')); ?>');">
<div class="container">
    <div class="row">
        <div class="col-12 text-center">
            <img src="<?php echo e(asset('frontend/images/contact_head.png')); ?>" alt="">
        </div>
    </div>
    <div class="row">
        <div class="col-md-12">
            <form class="row g-3" action="<?php echo e(route('contact')); ?>" method="POST">
                <?php echo csrf_field(); ?>
                <div class="col-md-6">
                    <label class="form-label"><?php echo e(NAME); ?></label>
                    <input type="text" class="form-control" name="name" placeholder="<?php echo e(YOUR_NAME); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label"><?php echo e(PHONE); ?></label>
                    <input type="text" class="form-control" name="phone" placeholder="<?php echo e(YOUR_PHONE); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label"><?php echo e(EMAIL_ADDRESS); ?></label>
                    <input type="text" class="form-control" name="email" placeholder="<?php echo e(YOUR_EMAIL_ADDRESS); ?>">
                </div>
                <div class="col-md-6">
                    <label class="form-label"><?php echo e(ADDRESS); ?></label>
                    <input type="text" class="form-control" name="address" placeholder="<?php echo e(ADDRESS); ?>">
                </div>

                <div class="col-12">
                    <label class="form-label"><?php echo e(MESSAGE); ?></label>
                    <textarea cols="5" rows="5" class="form-control" name="message" placeholder="<?php echo e(YOUR_MESSAGE); ?>"></textarea>
                </div>

                <div class="col-12 text-center">
                    <button type="submit" class="submit_btn"><?php echo e(SUBMIT_YOUR_REQUEST); ?></button>
                </div>
          </form>

        </div>
    </div>

</div>

</section>

<!-- diari start  -->
<section class="diari">
   <div class="heading_content">
    <div class="container-fluid">
        <div class="row">
           <div class="col-lg-10 m-auto">
            <h1 class="heading">Berger Home Diaries</h1>
            <p>We believe that homes are a reflection of the people who live inside, where everything looks and works the way you want it to. That’s why we’ve gathered tons of different home ideas, from home decoration ideas to organizing tips, to help you build your ideal home.</p>
           </div>
        </div>
    </div>
   </div>
   <div class="diari_item">
       <div class="container">
           <div class="row">
           <?php $__currentLoopData = $diarie; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
           <div class="col-xl-4 col-lg-4 col-md-6 col-sm-12 col-12">
                <div class="post">
                    <div class="post_image">
                        <img class="img-fluid" src="<?php echo e(asset('uploads/diarie')); ?>/<?php echo e($item->img); ?>" alt="">
                    </div>
                    <div class="post_content">
                        <a href="#"><h5><?php echo e($item->title); ?></h5></a>
                        <p><?php echo e($item->content); ?></p>
                    </div>
                </div>
            </div>
           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
           </div>
       </div>
   </div>
   <div class="row">
    <div class="col-12 text-center">
        <a class="more" href="#"><?php echo e(MORE_INSPRATIONS); ?></a>
    </div>
</div>
</section>
<!-- diari end  -->
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.frontend', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH E:\berger_work\resources\views/frontend.blade.php ENDPATH**/ ?>