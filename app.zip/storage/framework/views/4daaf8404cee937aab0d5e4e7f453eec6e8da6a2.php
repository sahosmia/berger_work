
<!DOCTYPE html>
<html lang="en">
  <head>
    <!-- Required meta tags -->
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">

    <!-- Twitter -->
    <meta name="twitter:site" content="@themepixels">
    <meta name="twitter:creator" content="@themepixels">
    <meta name="twitter:card" content="summary_large_image">
    <meta name="twitter:title" content="Bracket">
    <meta name="twitter:description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="twitter:image" content="http://themepixels.me/bracket/img/bracket-social.png">

    <!-- Facebook -->
    <meta property="og:url" content="http://themepixels.me/bracket">
    <meta property="og:title" content="Bracket">
    <meta property="og:description" content="Premium Quality and Responsive UI for Dashboard.">

    <meta property="og:image" content="http://themepixels.me/bracket/img/bracket-social.png">
    <meta property="og:image:secure_url" content="http://themepixels.me/bracket/img/bracket-social.png">
    <meta property="og:image:type" content="image/png">
    <meta property="og:image:width" content="1200">
    <meta property="og:image:height" content="600">

    <!-- Meta -->
    <meta name="description" content="Premium Quality and Responsive UI for Dashboard.">
    <meta name="author" content="ThemePixels">

    <title>Bracket Responsive Bootstrap 4 Admin Template</title>

    <!-- vendor css -->
    <link href="<?php echo e(asset('admin/lib/font-awesome/css/font-awesome.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/lib/Ionicons/css/ionicons.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/lib/perfect-scrollbar/css/perfect-scrollbar.css')); ?>" rel="stylesheet">
    <link href="<?php echo e(asset('admin/lib/jquery-switchbutton/jquery.switchButton.css')); ?>" rel="stylesheet">

    <!-- Bracket CSS -->
    <link rel="stylesheet" href="<?php echo e(asset('admin/css/bracket.css')); ?>">
  </head>

  <body>

    <!-- ########## START: LEFT PANEL ########## -->
    <div class="br-logo"><a href=""><span>[</span>bracket<span>]</span></a></div>
    <div class="br-sideleft overflow-y-auto">
      <label class="sidebar-label pd-x-15 mg-t-20">Navigation</label>
      <div class="br-sideleft-menu">
        <a href="<?php echo e(route('home')); ?>" class="br-menu-link <?php echo $__env->yieldContent('dashboard'); ?>">
          <div class="br-menu-item">
            <i class="menu-item-icon icon ion-ios-home-outline tx-22"></i>
            <span class="menu-item-label">Dashboard</span>
          </div><!-- menu-item -->
        </a><!-- br-menu-link -->
        <a href="<?php echo e(route('logo')); ?>" class="br-menu-link <?php echo $__env->yieldContent('logo'); ?>">
          <div class="br-menu-item">
            <i class="menu-item-icon icon ion-ios-email-outline tx-24"></i>
            <span class="menu-item-label">Logo</span>
          </div><!-- menu-item -->
        </a><!-- br-menu-link -->
        <a href="<?php echo e(route('slider')); ?>" class="br-menu-link <?php echo $__env->yieldContent('slider'); ?>">
          <div class="br-menu-item">
            <i class="menu-item-icon icon ion-ios-email-outline tx-24"></i>
            <span class="menu-item-label">Slider</span>
          </div><!-- menu-item -->
        </a><!-- br-menu-link -->
        <a href="<?php echo e(route('portfolio')); ?>" class="br-menu-link <?php echo $__env->yieldContent('portfolio'); ?>">
          <div class="br-menu-item">
            <i class="menu-item-icon icon ion-ios-email-outline tx-24"></i>
            <span class="menu-item-label">Portfolio</span>
          </div><!-- menu-item -->
        </a><!-- br-menu-link -->
        <a href="<?php echo e(route('diarie')); ?>" class="br-menu-link <?php echo $__env->yieldContent('diarie'); ?>">
          <div class="br-menu-item">
            <i class="menu-item-icon icon ion-ios-email-outline tx-24"></i>
            <span class="menu-item-label">Diarie</span>
          </div><!-- menu-item -->
        </a><!-- br-menu-link -->


      </div><!-- br-sideleft-menu -->


    </div><!-- br-sideleft -->
    <!-- ########## END: LEFT PANEL ########## -->

    <!-- ########## START: HEAD PANEL ########## -->
    <div class="br-header">
      <div class="br-header-left">
        <div class="navicon-left hidden-md-down"><a id="btnLeftMenu" href=""><i class="icon ion-navicon-round"></i></a></div>
        <div class="navicon-left hidden-lg-up"><a id="btnLeftMenuMobile" href=""><i class="icon ion-navicon-round"></i></a></div>
      </div><!-- br-header-left -->
      <div class="br-header-right">
        <nav class="nav">


          <div class="dropdown">
            <a href="" class="nav-link nav-link-profile" data-toggle="dropdown">
              <span class="logged-name hidden-md-down"><?php echo e(Auth::user()->name); ?></span>
              <img src="http://via.placeholder.com/64x64" class="wd-32 rounded-circle" alt="">
              <span class="square-10 bg-success"></span>
            </a>
            <div class="dropdown-menu dropdown-menu-header wd-200">
              <ul class="list-unstyled user-profile-nav">
                <li><a href=""><i class="icon ion-ios-person"></i> Edit Profile</a></li>
                <li><a href=""><i class="icon ion-power"></i> Sign Out</a></li>
              </ul>
            </div><!-- dropdown-menu -->
          </div><!-- dropdown -->
        </nav>
      </div><!-- br-header-right -->
    </div><!-- br-header -->
    <!-- ########## END: HEAD PANEL ########## -->


    <!-- ########## START: MAIN PANEL ########## -->
    <div class="br-mainpanel">


      <div class="br-pagebody pd-y-15 pd-l-20 pd-x-20 pd-sm-x-30 pd-b-20">
        <div class="row">
          <?php echo $__env->yieldContent('content'); ?>
        </div><!-- row -->
      </div><!-- br-pagebody -->

    </div><!-- br-mainpanel -->
    <!-- ########## END: MAIN PANEL ########## -->

    <script src="<?php echo e(asset('admin/lib/jquery/jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/lib/popper.js/popper.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/lib/bootstrap/bootstrap.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/lib/perfect-scrollbar/js/perfect-scrollbar.jquery.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/lib/moment/moment.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/lib/jquery-ui/jquery-ui.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/lib/jquery-switchbutton/jquery.switchButton.js')); ?>"></script>
    <script src="<?php echo e(asset('admin/lib/peity/jquery.peity.js')); ?>"></script>

    <script src="<?php echo e(asset('admin/js/bracket.js')); ?>"></script>
  </body>
</html>
<?php /**PATH C:\Users\sahos\OneDrive\Desktop\berger_work\resources\views/layouts/admin.blade.php ENDPATH**/ ?>