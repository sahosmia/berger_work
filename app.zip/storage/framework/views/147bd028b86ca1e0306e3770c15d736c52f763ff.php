<?php $__env->startSection('slider'); ?>
active
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
<div class="col-lg-6 m-auto">
    <?php if(session()->has('success')): ?>
    <div class="alert alert-success">
        <p><?php echo e(session()->get('success')); ?></p>
    </div>
    <?php endif; ?>

    <?php
        $all_fild = ['img',];
    ?>

    <?php $__currentLoopData = $all_fild; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php $__errorArgs = [$item];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
            <div class="alert alert-danger">
                <p><?php echo e($message); ?></p>
            </div>
        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <div class="card ">
        <div class="card-header text-center bg-teal text-light">
            <h4>Add Item</h4>
        </div>
        <div class="card-body">
            <form action="<?php echo e(route('slider_update')); ?>" method="post" enctype="multipart/form-data">
                <?php echo csrf_field(); ?>

                <input type="hidden" name="id" value="<?php echo e($data->id); ?>">

                <label>Existing Photo</label>
                <img class="w-25 d-block" src="<?php echo e(asset('uploads/slider')); ?>/<?php echo e($data->img); ?>" alt="<?php echo e($data->img); ?>">

                <label class="custom-file mt-4">
                    <input type="file" id="file" name="img" class="custom-file-input">
                    <span class="custom-file-control"></span>
                </label>

                <button type="submit" class="btn btn-teal d-block mt-4">Submit</button>
            </form>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\sahos\OneDrive\Desktop\berger\resources\views/admin/slider_edit.blade.php ENDPATH**/ ?>