@extends('layouts.admin')
@section('dashboard')
active
@endsection

@section('content')
<h1>Welcome Dashboard</h1>
@endsection
