@component('mail::message')
    {!! $data !!}
@endcomponent
