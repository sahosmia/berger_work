@extends('layouts.frontend')
@section('about')
active
@endsection


@section('content')
<h1>About</h1>
<h1>About</h1>
<h1>About</h1>
@endsection
