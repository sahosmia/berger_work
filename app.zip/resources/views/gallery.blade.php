@extends('layouts.frontend')
@section('gallery')
active
@endsection

@section('content')

<h1>Gallery</h1>
<h1>Gallery</h1>
<h1>Gallery</h1>
@endsection
