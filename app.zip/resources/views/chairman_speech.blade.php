@extends('layouts.frontend')
@section('corporate_speech')
active
@endsection


@section('content')
<h1>Chairman Speech</h1>
<h1>Chairman Speech</h1>
<h1>Chairman Speech</h1>
@endsection
