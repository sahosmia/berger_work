@extends('layouts.frontend')
@section('corporate_speech')
active
@endsection


@section('content')
<h1>MD Speech</h1>
<h1>MD Speech</h1>
<h1>MD Speech</h1>
@endsection
